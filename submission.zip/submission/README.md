## Buat virtual environtment dan install library
'''
conda create --name main-ds python = 3.12
conda active main-ds
pip install -r requirments.txt
'''
## Jalankan pada streamlit
'''
streamlit run dicoding-first-project.py
'''